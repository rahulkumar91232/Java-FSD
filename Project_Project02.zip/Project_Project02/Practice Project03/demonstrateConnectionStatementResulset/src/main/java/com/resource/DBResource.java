package com.resource;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBResource {
	
	static Connection con;
 
	static {
	
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con  = DriverManager.getConnection("jdbc:mysql://localhost:3306/productdetails", "root", "8875325200");
		   
		} catch (Exception e) {
			System.err.println("Db Connection error loaded only once "+e);
		
		}
	}
	
	public static Connection getDbConnection() {
		try {
			return con;
		} catch (Exception e) {
			System.err.println("Db Connection error "+e);
			return null;
		}
	}
	
	public static void closeConnection() {
		try {
			con.close();
		} catch (Exception e) {
			
		}
	}
}
