package com;

public class ThrowKeywordDemo {
	
        public static void main(String[] args)
        {

            int a=45;
            int b=0;
            
            int result;

            try
            {
                if(b==0)        
                    throw(new ArithmeticException("Can't divide by zero."));
                else
                {
                	result = a / b;
                	
                    System.out.print("\n\tThe result is : " + result);
                }
            }
            catch(ArithmeticException e)
            {
                System.out.println("Error : " + e.getMessage());
            }

            System.out.println("End of program.");
        }
    

}
