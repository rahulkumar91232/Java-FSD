package com;

public class ThrowsKeywordDemo {
	
	
     static void division() throws ArithmeticException{
    
        int a=45;
        int b=0;
        int result = a / b;
        System.out.println("The result is : " + result);
    }
     public static void main(String[] args) {
    
    	 
         try
        {
            division();
        }
        catch(ArithmeticException e)
        {
            System.out.println("Error occurred : " + e.getMessage());
        }
        System.out.println("End of program.");
    }


}
