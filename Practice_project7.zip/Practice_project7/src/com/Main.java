package com;

public class Main {

	public static void main(String[] args) {
		
		
		OuterClass.InnerClass inn = new OuterClass().new InnerClass();
		        inn.displayInnerClass();

	}

}
