package Regex;

import java.util.regex.Pattern;

public class RegexExample {

	public static void main(String[] args) {
	
		
		
		String userName ="MphasiS"; // nName to be checked .
		
		nameValidation(userName);  // nameValidation Method is called .
		

	}
	
	public static void nameValidation(String userName ) {
		
			String name = "mphasis";  //  Pattern to which userName will be matched .
			
			Pattern pattern = Pattern.compile(name,Pattern.CASE_INSENSITIVE);
			
			if(pattern.matcher(userName).matches()) 
				System.out.println("Match found");
				
			
			else     System.out.println("Did not match");
		}
		
		
	

}
