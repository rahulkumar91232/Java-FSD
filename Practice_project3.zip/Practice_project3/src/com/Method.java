package com;

public class Method {
	
	
	public void publicMethod() {
		System.out.println("This is a public Method");
	}
	
	public static void staticMethod() {
		System.out.println("This is a  static Method");
	}
	
	
	
	public static void main(String args[]) {
		
		
		// calling of static method 
		
		staticMethod();    // if method is static , we can directly call it  in main method if in same class.
		Method.staticMethod();  // we can call a method by using ClassName.methodname .
		
		Method m = new Method();
		   m.staticMethod();    //  we can call method by creating object of the class in which method exist.
		   
		     A sc = new A();    
		    sc.staticMethod2();  // we can call static method from different class by creating object of that class and calling through it
		    
		    A.staticMethod2(); // we can call static method exist in another class by ClassName.methodname  .
		   
		   
		   
		   // calling of non- static method
		   
		   publicMethod();
		   Method.publicMethod();  //  we can not call non static method directly  or by className.methodName .
		   
		   m.publicMethod();   // we can call a non- static method by creating object of that class and calling through the object created.
		  
		   A s = new A(); 
		   s.publicMethod1();   // we can call a non- static method by creating object of that class and calling through the object created.
		  
		   
	}

}
