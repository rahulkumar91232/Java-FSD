package map;

import java.util.HashMap;
import java.util.Map;

public class MapImplementation {
	
	
    public static void main(String args[]) {
	
	
	Map<Integer, String > map = new HashMap<Integer, String >();
	
	
	map.put(1, "Rajesh");
	map.put(2, "Ramesh");
	map.put(3, "Lokesh");
	map.put(4, "Pintu");
	map.put(5, "Ajay");
	map.put(6, "Salman");
	map.put(7, "Divya");
	map.put(8, "Priyanka");
	map.put(9, "Madhuri");
	map.put(10, "Rani");
	
	for(Map.Entry<Integer, String > m : map.entrySet()) {
		System.out.print(m.getKey()+":");
		System.out.println(m.getValue());
	}
	
    }
}
