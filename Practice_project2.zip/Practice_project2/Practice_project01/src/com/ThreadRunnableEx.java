package com;

public class ThreadRunnableEx implements Runnable {
	 
	int count = 1;
		 
	    
	    public void run() {
	         while(count<=5)
	            try{
	            	
	                System.out.println("thread stated running..");
	                System.out.println("thread "+count);
	                
	                count++;
	                
	                Thread.sleep(2000);
	                
	            } catch (InterruptedException e) {
	                System.out.println("Exception in thread: "+e);
	            }
	         
	    } 
	    public static void main(String a[]){
	    	
	    	System.out.println("Starting Main Thread...");
	        
	        ThreadRunnableEx td = new ThreadRunnableEx();
	        Thread t = new Thread(td);
	        t.start();
	     
	        System.out.println(" Main Thread ended");
	    }
	

}
