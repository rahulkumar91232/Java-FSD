package com;

public class ConstructorType {
	
	int id ;
	String Name;
	double salary;
	
	
	// non-parameterized constructor has no any parameter or argument .
	ConstructorType(){
		
		System.out.println("This is non-parameterized constructor");
		
	}
	
	
	
	// parameterized constructor has  parameter or argument .
	
	ConstructorType(int id){
		System.out.println("This is parameterized constructor");  // parameterized constructor with 1 parameter .
		this.id = id;
	}
	
	ConstructorType(int id, String name){
		System.out.println("This is parameterized constructor");   //    parameterized constructor with 2 parameters .
		this.id = id;
		this.Name = name;
		
	}
	
	ConstructorType(int id, String name, double salary){
		System.out.println("This is parameterized constructor");   //    parameterized constructor with 3 parameters .
		
		this.id = id;
		this.Name = name;
		this.salary = salary;
	}
	
	

}
