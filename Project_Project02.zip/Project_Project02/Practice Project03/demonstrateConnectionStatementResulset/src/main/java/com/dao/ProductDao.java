package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.bean.Product;
import com.mysql.cj.protocol.Resultset;
import com.resource.DBResource;

public class ProductDao {

	static DBResource pr = new DBResource();
	
    public  int addProduct(Product product) throws SQLException {
    	int pid=product.getPid();
    	String pname = product.getPname();
    	float price =  product.getPrice();
    	Connection con = DBResource.getDbConnection();
    	PreparedStatement pstmt = con.prepareStatement("insert into product values(?,?,?)");
    	
    	pstmt.setInt(1, pid);
    	pstmt.setString(2, pname);
    	pstmt.setFloat(3, price);
    	
    	int result = pstmt.executeUpdate();
		return result;
	}
	
	
	public ResultSet retrieveProduct(int pid) {
		try {
			Connection con = DBResource.getDbConnection();
			PreparedStatement pstmt = con.prepareStatement("select * from product where pid = ? ");
			pstmt.setInt(1, pid);
			
			ResultSet resultset =pstmt.executeQuery();
			System.out.println(resultset);
			return resultset ;
			} catch (Exception e) {
				System.err.println("Product update exception"+e);
				return null;
			}
		
	}
}
