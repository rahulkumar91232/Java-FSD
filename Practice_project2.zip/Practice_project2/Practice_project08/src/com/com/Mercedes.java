package com.com;



class Mercedes extends Car{

		Mercedes(String color, int gear, int speed) {
			super(color, gear, speed);
			
		}
		
		void run(){
			System.out.println("Mercedes is ruuning at speed of "+speed);
			
		}
		 
	
}
