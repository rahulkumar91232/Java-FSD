package com;


//   Daimond problem code 


//interface A{
//	default void run() {
//		System.out.println("This Method is in interface A . ");
//	}
//}
//
//interface B extends A{
//	@Override
//	default void run() {
//		System.out.println("This method is in interface B .");
//	}
//}
//interface c extends A{
//	@Override
//	default void run() {
//		System.out.println("This method is in interface C .");
//	}
//}
//
//public class DiamondDemo implements B,c {          // here amguity gets generated . compiler gets confused which method to get 
//	                                               // from interface B or interface C .
//
//	public static void main(String[] args) {
//	
//       DiamondDemo dd = new DiamondDemo();
//          dd.run();
//	}
//
//}




//code to solve Diamond problem


interface A{
	default void run() {
		System.out.println("This Method is in interface A . ");
	}
}

interface B extends A{
	default void run() {
		System.out.println("This method is in interface B .");
	}
}

interface C extends A{
	@Override
	default void run() {
		System.out.println("This method is in interface C .");
	}
}	

public class DiamondDemo implements B,C{
	
	public void run() {     
		C.super.run();          // This solve the Diamond problem . Here if we do B.super.rum() then dd object will run() method in B .
	}                           // And if we do C.super.rum() then dd object will run() method in C .

	public static void main(String[] args) {
	
    DiamondDemo dd = new DiamondDemo();
       dd.run();
	}
}	









