package com;

public class ThreadDemo extends Thread{
	 

	 	public void run() {
	 	
	 		
	  		System.out.println("current thread started running..");
	  		
	    } 
	 	
	 	
	 	public static void main( String args[] ) {
	 	
	 	
	  		ThreadDemo td = new  ThreadDemo();
	  		
	  		td.start();
	 	}
	

}
