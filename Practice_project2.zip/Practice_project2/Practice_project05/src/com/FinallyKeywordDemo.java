package com;

public class FinallyKeywordDemo {
	 static int result = 0;
    static void division() throws ArithmeticException{
        
        int a=45;
        int b=0;
       
        result = a / b;
        System.out.println("The result is : " + result);
    }
     public static void main(String[] args) {
    
    	 
         try
        {
            division();
        }
        catch(ArithmeticException e)
        {
            System.out.println("Error occurred : " + e.getMessage());
        }finally {
        	System.out.println("final result for division is : "+result);
        }
         
        System.out.println("End of program.");
    }
}
