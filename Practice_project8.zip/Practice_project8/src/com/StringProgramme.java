package com;

public class StringProgramme {
	
	public static void main(String args[]) {
		
		String name ="Mphasis is a big MNC.";
		
		//  String to StrinBuffer conversion 
		
		StringBuffer st = new StringBuffer (name);   // One way to convert String to String buffer .
		System.out.println("String Converted to StringBuffer : "+ st);
		
		
		  StringBuffer ps = new StringBuffer();
		  ps.append(name);  //   another way to convert String to StringBuffer. 
		System.out.println("String Converted to StringBuffer : "+ st);
		
		
		// String to StrinBuilder conversion 
		
		StringBuilder sb = new StringBuilder();
		 sb.append(name);
		 
		 System.out.println("String Converted to StringBuilder : "+ sb);
		
	}

	
	
}
