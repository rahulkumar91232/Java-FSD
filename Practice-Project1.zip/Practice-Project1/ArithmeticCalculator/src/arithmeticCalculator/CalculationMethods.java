package arithmeticCalculator;

public class CalculationMethods {
	
	
	public void add(double firstNum , double secondNum) {

		double addResult = firstNum + secondNum ;
		
		System.out.println("Addtion result is "+addResult);


	}
	public void subtract(double firstNum , double secondNum) {

		double subtractResult = firstNum - secondNum ;
		System.out.println("Subtraction result is "+ subtractResult);

	}
	public void multiply(double firstNum , double secondNum) {

		double multiplyResult = firstNum*secondNum ;
		System.out.println("Multiplication result is "+multiplyResult);

	}
	public void divide(double firstNum , double secondNum) {
		if(secondNum ==0) {
			System.out.println("Error. A Number can not be divided by Zero ");
		}

		else {
			double divideResult = firstNum/secondNum ;
		
		    System.out.println("Division result is "+divideResult);
		}
	}

}
