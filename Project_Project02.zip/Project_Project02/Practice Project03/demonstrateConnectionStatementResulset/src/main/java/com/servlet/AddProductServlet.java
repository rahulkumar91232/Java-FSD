package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.Product;
import com.service.ProductService;

/**
 * Servlet implementation class AddProductServlet
 */
public class AddProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddProductServlet() {
        super();
        // TODO Auto-generated constructor stub
    }


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
    ProductService ps = new ProductService();
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		int  pid = Integer.parseInt(request.getParameter("pid"));
		String pname = request.getParameter("pname");
		float  price=  Float.parseFloat(request.getParameter("price"));
		
		Product p = new Product(pid,pname,price);
		
		
		RequestDispatcher rd = request.getRequestDispatcher("addProduct.html");
		try {
			if(ps.addProduct(p)>0) {
				pw.println("Record inserted Successfully.");
				rd.include(request, response);
				
			}
			
			
			
		}catch(Exception e) {
			pw.println("record not inserted.");
			rd.include(request, response);
			
		}
		
		response.setContentType("text/html");
	}

}
