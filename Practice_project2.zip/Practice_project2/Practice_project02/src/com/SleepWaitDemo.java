package com;

public class SleepWaitDemo {
	
        static int total = 10;
	     static Object LOCK = new Object();
	    
	    
	    public static void main(String args[]) throws InterruptedException
	    {
	        
	        for(int i=0;i<=10;i++) {
	        	
	        	total=total+i;
	        	
	        	System.out.println(total);
	        	
	        	Thread.sleep(3000);
	        	
	        	 
		        System.out.println("Thread " + Thread.currentThread().getName() + " is woken after sleeping for 3 second");
		        
	        }
	       
	        synchronized (LOCK) 
	        {
	            LOCK.wait(2000);
	            
	            System.out.println("Object " + LOCK + "is woken after" + " waiting for 2 second");
	        }
	    }
	

}
