package com;



public class ArrayRotaion
{
	public static void main(String[] args) {

		int arr[] = { 1, 2, 3, 4, 5, 6, 7 }; 
		rotateArray(arr, 5); 
		for(int i=0;i<arr.length;i++){
			System.out.print(arr[i]+" ");
		}
	}
	public static void rotateArray(int[] arr, int steps) {
		if(steps > arr.length) 
			steps=steps%arr.length;
		int[] result = new int[arr.length];
		for(int i=0; i < steps; i++){
			result[i] = arr[arr.length-steps+i];
		}
		int j=0;
		for(int i=steps; i<arr.length; i++){
			result[i] = arr[j];
			j++;
		}
		System.arraycopy( result, 0, arr, 0, arr.length );

	} 


}
