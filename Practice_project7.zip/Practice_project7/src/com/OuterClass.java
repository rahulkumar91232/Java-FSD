package com;

public class OuterClass {

	
	public class InnerClass{
		
		
		
		
		public void displayInnerClass() {
			
			System.out.println("This method is inside inner class");
			
		}
	}
	
	
	
}
