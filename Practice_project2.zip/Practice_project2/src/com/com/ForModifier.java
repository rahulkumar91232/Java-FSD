package com.com;

public class ForModifier {
	
	


	public void publicMethod2() {
		System.out.println("This is public Method 2");
		
	}
	
	protected void protectedMethod() {
		System.out.println("This method is protected");
		
	}

}
