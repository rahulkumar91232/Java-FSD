package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.dao.DbResource;

/**
 * Servlet implementation class DeleteDatabaseServlet
 */
public class DeleteDatabaseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteDatabaseServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    DbResource dr = new DbResource();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String dbName = request.getParameter("databaseName");
		PrintWriter pw = response.getWriter();
		RequestDispatcher rd1 = request.getRequestDispatcher("index.html");
		RequestDispatcher rd2 = request.getRequestDispatcher("deleteDatabase.html");
		try {
			dr.deleteDatabase(dbName);
			pw.println("Database deleted successfully.");
		    rd1.include(request, response);
			
		}catch(Exception e) {
			pw.println("Exception occurred : "+e);
			rd2.include(request, response);
	
		}
		response.setContentType("text/html");	
	}
}
