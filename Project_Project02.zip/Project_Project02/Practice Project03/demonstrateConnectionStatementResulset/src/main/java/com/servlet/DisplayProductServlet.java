package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.Product;
import com.service.ProductService;

/**
 * Servlet implementation class DisplayProductServlet
 */
public class DisplayProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	
	 ProductService ps = new ProductService();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		int  pid = Integer.parseInt(request.getParameter("pid"));
		
		RequestDispatcher rd = request.getRequestDispatcher("displayProduct.html");
		try {
			    Product product= ps.displayProduct(pid);
				pw.println("Record is : "+product);
				rd.include(request, response);
				
		}catch(Exception e) {
			pw.println("record not inserted.");
			rd.include(request, response);
			
		}
		
		response.setContentType("text/html");
	}

}
