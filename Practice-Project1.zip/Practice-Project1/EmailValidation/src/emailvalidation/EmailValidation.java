package emailvalidation;
import java.util.Scanner;
import java.util.regex.Pattern;

public class EmailValidation {

	public static void main(String[] args) {
		
		System.out.println("***********************************");
		
		System.out.println("Welcome to Email validation Page");
		
		System.out.println("***********************************");
		
		System.out.println("Enter the Email to be checked");
		
		Scanner sc =  new Scanner(System.in);
		     
		   String email = sc.nextLine();
		 
		emailValidate(email); 
		

	}
	
	public static void emailValidate(String email ) {
		if(email == null || email.isEmpty()) {
			System.out.println("Entered Email is Invalid");
		}
		else {
			String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+"[a-zA-Z0-9_+&*-]+)*@"+"(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
			
			Pattern pattern = Pattern.compile(emailRegex);
			
			if(pattern.matcher(email).matches()) 
				System.out.println(" This is a Valid Email");
				
			
			else     System.out.println("Invalid Email");
		}
		
		
	}
	

}
