package com.service;

import java.sql.SQLException;

import com.bean.Product;
import com.dao.ProductDao;

public class ProductService {
	
	ProductDao pd= new ProductDao();
	
	public int addProduct(Product product) throws SQLException {
		int result = pd.addProduct(product);
		return result;
		
	}
	
	
	public int updateProduct(Product product) {
		
		int result=pd.updateProduct(product);
		return result;
		
	}
	
	
	public int deleteProduct(int pid) {
		
		int result = pd.deleteProduct(pid);
		return result;
		
	}

}
