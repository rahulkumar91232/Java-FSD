package com;

public class CustomExceptionDemo extends Exception {

	    CustomExceptionDemo(String str){
	    	super(str);
	    }
	
	
	
    
    public static void main(String args[]) {
    
        try
        { 
            throw new CustomExceptionDemo("This is a custom exception"); 
        } 
        catch (CustomExceptionDemo e) 
        { 
           
            System.out.println(e.getMessage()); 
        } 
    } 


}
