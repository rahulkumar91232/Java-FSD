package collection;

import java.util.ArrayList;

public class CollectionExample {

	public static void main(String[] args) {
		
		
		ArrayList<String> studentList = new ArrayList<String>();
		
		studentList.add("Raj");
		studentList.add("Ravi");
		studentList.add("Mohit");
		studentList.add("Dinkar");
		studentList.add("Akash");
		studentList.add("Brajesh");
		studentList.add("Lakhan");
		studentList.add("Kartik");
		studentList.add("Om prakash");
		
		System.out.println("Student in studentList are :");
		for(String name : studentList) {
			
			System.out.println(name);
			
		}

	}

}
