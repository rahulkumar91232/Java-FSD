package com;

import java.io.File;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileOperationDemo {

	public static void main(String[] args) throws IOException {
		
		
		//  code to create new file 
		
		File myFile = new File("file.txt");
		   
		    myFile.createNewFile();
		    System.out.println("File created successfully");
		    
		    
		    
		    
		    // code to write on file
		    
		    FileWriter fileWriter = new FileWriter("file.txt");
		          
		             fileWriter.write("i am doing Java-FSD Training .");
		             
		             fileWriter.close();
		             
		        System.out.println("File written successfully.");   
		        
		        
		        
		        
		        // code to read file
		        
		        File myFile2 = new File("file.txt");
		        Scanner sc = new Scanner(myFile2);
		        
		        while(sc.hasNextLine()) {
		        	String line = sc.nextLine();
		        	System.out.println(line);
		        }
		        sc.close();
		        
		        
		        
		        
		        // code to delete file
		        
		        File myFile3 = new File("go.txt");
		        
		        boolean deleted = myFile3.delete();
		        
		        System.out.println(deleted);
		        
		        if(deleted) {
		        	System.out.println("File has been deleted successfully");
		        }else {
		        	System.out.println("some error occurred while deleting file .");
		        }
		        
		
	}
	
}
