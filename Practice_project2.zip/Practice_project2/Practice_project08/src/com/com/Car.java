package com.com;

public class Car {
		String color;
		int gear;
		int speed;
		
		
		Car(String color, int gear, int speed){
			this.color = color;
			this.gear = gear;
			this.speed = speed;
		}
		
		void run() {
			
		}
	
}
