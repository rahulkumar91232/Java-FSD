package com;

public class AccessModifierClass {
   private int salary;
   
   
   private void privateMethod() {
	   System.out.println("This  is private method");
   }
   
   public void publicMethod() {
	   System.out.println("This method is public");
   }
   
   
   

	 void defaultMethod() {
		 System.out.println("This is default method example");
		
	}
   
	 
	 protected void protectedMethod() {
		 System.out.println("This is example of protected  method");
	 }
   
   
   
}
