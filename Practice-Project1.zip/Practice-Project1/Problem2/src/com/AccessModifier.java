package com;

import com.com.ForModifier;

public class AccessModifier {
	
	
	public void salaryCalculation() {
		
	}
	
	void studentInfo() {
		
	}

	public static void main(String[] args) {
		AccessModifierClass ad = new AccessModifierClass();
		
		// private access modifier example
		
		ad.salary =10000;
		ad.privateMethod() ;     //    instance variable and method with 'private' access modifier 
		                          //  can not be called even by creating object of the class and calling through the created object.
		
		
		
		
		// public access modifier examoles
		
		ad.publicMethod();    // method with 'public' access Modifier can be called from outside class and within same package .

		AccessModifier am = new AccessModifier();
		am.salaryCalculation();       //      method with 'public' access Modifier can be called within the same class.


		ForModifier sc = new ForModifier();
		sc.publicMethod2();       //  method with 'public' access Modifier can be called from outside the package. 
		                          // But we need to import the package in that class and method exists.
		
		
		
		// default access modifier example
		
		ad.defaultMethod(); //   if no access modifier is specified, it is considered default . 
		am.studentInfo();                   // default method is accessible within same package.
        
		
		// protected access modifier example
		
		ad.protectedMethod();  // protected method can be called from same package.
		
		
	}

}
