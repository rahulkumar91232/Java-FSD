package com;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class FourthSmallestElementArrayList {
	
	
    public static int findFourthSmallest(ArrayList<Integer> list) {
        // Check if the ArrayList has at least four elements
        if (list.size() < 4) {
            System.out.println("ArrayList has less than four elements.");
            return -1; 
        }

        // Convert ArrayList to array
        Integer[] arr = new Integer[list.size()];
        arr = list.toArray(arr);

        // Sort the array in ascending order
        Arrays.sort(arr);

        // Return the fourth smallest element
        return arr[3];
    }

    public static void main(String[] args) {
        ArrayList<Integer> unsortedList = new ArrayList<>();
        unsortedList.add(9);
        unsortedList.add(3);
        unsortedList.add(7);
        unsortedList.add(1);
        unsortedList.add(5);
        unsortedList.add(6);
        unsortedList.add(2);
        unsortedList.add(8);
        unsortedList.add(4);

        int fourthSmallest = findFourthSmallest(unsortedList);

        if (fourthSmallest != -1) {
            System.out.println("The fourth smallest element is: " + fourthSmallest);
        }
    }
}