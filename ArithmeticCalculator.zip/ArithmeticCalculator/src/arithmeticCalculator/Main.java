package arithmeticCalculator;

import java.util.Scanner;

public class Main {
	static double firstNum;
	static double secondNum;
	static boolean flag =true;
	
	public static void main(String args[] ){
		System.out.println("-----------------------------------");
		System.out.println("Arithmetic Calculator");
		
		System.out.println("-----------------------------------");
		
		while(flag) {
		
		System.out.println("Choose your option");
		
		System.out.println("1. Add"+"  "+
		                    "2. Subtract"+"  "+
				            "3. Multiply"+"  "+
		                    "4. Divide");
		
		
		Scanner sc= new Scanner(System.in);
		        int userChoice = sc.nextInt();
		       CalculationMethods cm = new CalculationMethods();
		       switch(userChoice) {
		       
		                     case 1 :   System.out.println("You have opted for addition operation");
		                     
		                    	        System.out.println("Enter first Number");
		                    	        
		                    	         firstNum = sc.nextDouble();
		                    	         
		                    	        System.out.println("Enter Second Number");
		                    	        
		                    	         secondNum = sc.nextDouble();
		                    	         
		                    	         cm.add(firstNum,secondNum);
		                    	         
		                    	        break;
		                    	        
		                     case 2 :   System.out.println("You have opted for Subtraction operation");
		                     
		                                System.out.println("Enter first Number");
		                                
		                                 firstNum = sc.nextDouble();
		                                 
		                                System.out.println("Enter Second Number");
		                                
		                                 secondNum = sc.nextDouble();
		                                 
		                                 cm.subtract(firstNum,secondNum);
		                                 
		                                break;
		                                
		                     case 3 :   System.out.println("You have opted for multiplication operation");
		                     
		                                System.out.println("Enter first Number");
		                                
		                                  firstNum = sc.nextDouble();
		                                  
		                                 System.out.println("Enter Second Number");
		                                 
		                                  secondNum = sc.nextDouble();
		                                  
		                                  cm.multiply(firstNum,secondNum);
		                                  
		                                 break;
		                                 
		                     case 4 :   System.out.println("You have opted for division operation");
		                     
		                                System.out.println("Enter first Number");
		                                
		                                 firstNum = sc.nextDouble();
		                                 
		                                System.out.println("Enter Second Number");
		                                
		                                 secondNum = sc.nextDouble();
		                                 
		                                 cm.divide(firstNum,secondNum);
		                                 
		                                break;
		       
		                    default :   System.out.println("You have entered wrong option.");
		                                
		                                System.out.println("Want to continue or Exit ?" +"  "+"1. continue "+"  "+"2. Exit");
		                                int choice = sc.nextInt();
		                                if(choice==2) {
		                                	flag=false;
		                                	System.out.println("Exiting...");
		                                }
		                                 
		                                break;
		       
		       
		       }
		     
		}
		
	}

}
