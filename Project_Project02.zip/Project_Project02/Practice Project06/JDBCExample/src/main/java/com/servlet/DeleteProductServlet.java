package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.Product;
import com.service.ProductService;

/**
 * Servlet implementation class DeleteProductServlet
 */
public class DeleteProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteProductServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
    ProductService ps = new ProductService();
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		int  pid = Integer.parseInt(request.getParameter("pid"));
		
		RequestDispatcher rd = request.getRequestDispatcher("deleteProduct.html");
		try {
			if(ps.deleteProduct(pid)>0) {
				pw.println("product deleted successfully.");
				rd.include(request, response);
			}
			
			
		}catch(Exception e) {
			pw.println("product is not deleted . Some error occurred.");
			rd.include(request, response);
			
		}
		response.setContentType("text/html");
	}	

}
