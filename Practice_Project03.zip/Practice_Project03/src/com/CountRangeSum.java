package com;

public class CountRangeSum   
{  
	// a method that computes the count of ranges (subarrays) whose  
	// sum lies in the range left and right (left and right inclusive)  
	public int findCountRangeSum(int numArr[], int size, int left, int right)  
	{  
		long tmp = 0;  
		int count = 0;  

		// Checking all of the subarrays  
		// that can be made from the input array numArr[]  
		for (int j = 0; j < size; j++)  
		{  
			tmp = 0;  
			for (int i = j; i < size; i++)  
			{  
		
				tmp = tmp + numArr[i];  

				
				if(tmp >= left && tmp <= right)  
				{  
					count = count + 1;  // If the sum is present within the range, then increment the count by 1  
				}  
			}  
		}  
		return count;  
	}  

	// main method  
	public static void main(String argvs[])  
	{  
		CountRangeSum obj = new CountRangeSum();  

	
		int numArr[] = {1, 2, 3, 4, 5, 6, 7};   	// input array  

		
		int size = numArr.length;   // computing its size  

		// defining the ranges, i.e, the left and the right boundary   
		int l = 2;   // left range
		int r = 7;   // Right range

		// invoking the method findCountRangeSum() and storing the answer  
		int ans = obj.findCountRangeSum(numArr, size, l, r);  

		System.out.println("For the input array: ");  

		for(int i = 0; i < size; i++)  
		{  
			System.out.print(numArr[i] + " ");      
		}  
		System.out.println();  

		if(ans != 0)  
		{  
			System.out.print("The number of ranges whose sum lies between "+ l + " & " + r + " is " + ans + ".");  
		}  
		else  
		{  
			System.out.print("There is no range whose sum lies between "+ l + " & " + r + ".");      
		}  

		System.out.println("\n");  

		// input array  
		int numArr1[] = {11, 12, 13, 14, 15, 16, 17};  

		 
		size = numArr1.length;  

		// defining the ranges, i.e, the left and the right boundary   
		l = 9;  
		r = 10;  

		// invoking the method findCountRangeSum() and storing the answer  
		ans = obj.findCountRangeSum(numArr1, size, l, r);  

		System.out.println("For the input array: ");  

		for(int i = 0; i < size; i++)  
		{  
			System.out.print(numArr1[i] + " ");      
		}  
		System.out.println();  

		if(ans != 0)  
		{  
			System.out.print("The number of ranges whose sum lies between "+ l + " & " + r + " is " + ans + ".");  
		}  
		else  
		{  
			System.out.print("There is no range whose sum lies between "+ l + " & " + r + ".");      
		}  
	}  

} 
