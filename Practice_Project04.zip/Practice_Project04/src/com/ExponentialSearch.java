package com;

import java.util.Arrays;
import java.util.Scanner;

public class ExponentialSearch {


	public static  void main(String[] args){

		int[] arr = {6,12,18,24,32,45,78,89,65};
		System.out.print(" Array Taken is : ");
		for(int a : arr) {
			System.out.print(a+" ");
		}
		System.out.println(" ");
		int length= arr.length;
		System.out.println("Enter the element to search ");
		Scanner sc = new Scanner(System.in);
		int SearchElement = sc.nextInt();
		int searchedResult = exponentialSearch(arr,length,SearchElement);

		if(searchedResult<0){

			System.out.println( "Element is not present in the array");

		}else {

			System.out.println( "Element is  present in the array at index :"+searchedResult);
		}

	}

	public static int exponentialSearch(int[] arr ,int length, int SearchElement ){

		if(arr[0]==SearchElement){
			return 0;
		}
		int i=1;
		while(i<length && arr[i]<=SearchElement){

			i=i*2;
		}
		return Arrays.binarySearch(arr,i/2,Math.min(i,length),SearchElement);
	}

}

