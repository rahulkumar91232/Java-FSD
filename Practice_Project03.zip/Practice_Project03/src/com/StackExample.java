package com;

import java.util.Scanner;
import java.util.Stack;

public class StackExample {

    
    	public static void main(String args[]) {

        		Stack st = new Stack(); 
        		
        		st.push("Ramesh");   
        		
        		                     
        		st.push("rohit"); 
        		
        		st.push("Lakshmi");
        		
        		st.push("Kamal");               // Stack follow FILO (First In Last Out)
        		
        		st.push(100);
        		
        		st.push("Kumar");          // push() method is used to add the element to Stack
        		
        		st.push(40);
        		
        		st.push('A');
        		
        		st.push("Kartik");
        		
        		st.push(68);
        		
        		System.out.println(st.pop() + " Popped from stack");   //  pop() method is used to remove last entered element from Stack
        		
        		System.out.println("Stack after first popped operation is : "+st);
        		
        		System.out.println(st.pop() + " Popped from stack"); 
        		
        		System.out.println("Stack after 2nd poped operation is : "+st);
        		
        		
    	}
} 	

