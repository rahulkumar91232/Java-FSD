package com;

import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;

public class QueueExamples {

	public static void main(String[] args) {
	Queue q1 = new PriorityQueue();

	Queue q2 = new LinkedList();
	
	System.out.println("Queue using PriorityQueue");
	
	q1.add(3);
	
	System.out.println("queue after adding first element : "+q1);
	System.out.println("");
	q1.add(8);
	q1.add(7);        // Queue Follow FIFO (First In First Out)
	q1.add(4);
	q1.add(5);
	q1.add(1);
	
	System.out.println(q1);  // Queue element is displayed.
	System.out.println("Removed element is : "+q1.poll()); 
	System.out.println("");// top element is removed
	System.out.println("queue after removing first element :"+q1);
	System.out.println("");
	System.out.println("Removed  element is : "+q1.poll());
	System.out.println("");
	System.out.println("queue after removing another element :"+q1);

	
	
	System.out.println("");
	System.out.println("Queue using LinkedList");
	System.out.println("");
	
	q2.add(30);
	q2.add(18);
	q2.add(77);
	q2.add(43);
	q2.add(52);
	q2.add(11);
	
	System.out.println("elements in queue is "+q2);
	
	System.out.println("Removed element : "+q2.poll());
	
	System.out.println("queue after removing another element :"+q2);
	}

}