/**
 * 
 */
/**
 * 
 */
module Arithmeticcalculator {
}