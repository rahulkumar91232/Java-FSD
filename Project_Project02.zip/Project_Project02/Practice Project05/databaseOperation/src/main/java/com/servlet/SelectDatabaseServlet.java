package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.Database;
import com.dao.DbResource;

/**
 * Servlet implementation class SelectDatabaseServlet
 */
public class SelectDatabaseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SelectDatabaseServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    DbResource dr = new DbResource();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String dbName = request.getParameter("databaseName");
		PrintWriter pw = response.getWriter();
		RequestDispatcher rd1 = request.getRequestDispatcher("index.html");
		RequestDispatcher rd2 = request.getRequestDispatcher("selectDatabase.html");
		try {
			dr.selectDatabase(dbName);
			pw.println("Database selected successfully.");
			rd1.include(request, response);
		}catch(Exception e) {
			pw.println("Database not selected.");			
			pw.println("Exception occurred : "+e);
			rd2.include(request, response);
		}
		response.setContentType("text/html");
	}	

}
