package com;

import java.util.Arrays;
import java.util.Scanner;

public class BinarySearch {

	public static void main(String[] args) {
		
		 int[] arr = {10,25,56,48,35,89,47,56,30,78,457,145,123,12};
		 Arrays.sort(arr);  // binary Search works only on sorted array . Array.sort() method will sort array provided.
		 System.out.println("Array after sorting ");
		 for(int a : arr){
			 System.out.print(a+" ");       // for each loop to print sorted array.
		 }
		 System.out.println();
		 System.out.println("Enter the element to search");
		 Scanner sc = new Scanner(System.in);
		       int search = sc.nextInt();          // user given element to search
		       sc.close();
		 
		 int start=0;
		 int end = arr.length-1;
		int mid = (start+end)/2;

		while(start<=end) {
			if(arr[mid]<search) {
				start = mid+1;
			}else if(arr[mid]==search) {
				System.out.println("Element is found "+mid);
				break;
			}else {
				end = mid-1;
			}
			mid = (start +end )/2;
		}
		if(start > end) {
			System.out.println("Element is not found");
		}
	}



}
