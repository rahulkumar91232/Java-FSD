package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class JdbcSetUpServlet
 */
public class JdbcSetUpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public JdbcSetUpServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    static final String DB_URL = "jdbc:mysql://localhost:3306/";
    static final String USER = "root";
    static final String PASS = "8875325200";
    static Connection con;
    
    // method to set JDBC connection with database 
    public static void createConnection() throws SQLException{
		   
		   try {
			        Class.forName("com.mysql.cj.jdbc.Driver");
			        con = DriverManager.getConnection(DB_URL, USER, PASS);
		   } catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		  } 
	   }
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		    PrintWriter pw = response.getWriter();
		    RequestDispatcher rd = request.getRequestDispatcher("index.html");
		    try {
		    	pw.print("Creating JDBC connection...."+"<br>");
				createConnection();
				if(con!=null) {
					pw.print("JDBC connection created Successfully");
					
				}
			} catch (SQLException e) {
				pw.print("some error happened while creating connection"+e);
				
			}
		    response.setContentType("text/html");
		    
	}

}
