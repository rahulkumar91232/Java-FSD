package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.bean.Product;
import com.resource.DBResource;

public class ProductDao {

	static DBResource pr = new DBResource();
	
    public  int addProduct(Product product) throws SQLException {
    	int pid=product.getPid();
    	String pname = product.getPname();
    	float price =  product.getPrice();
    	Connection con = DBResource.getDbConnection();
    	PreparedStatement pstmt = con.prepareStatement("insert into product values(?,?,?)");
    	
    	pstmt.setInt(1, pid);
    	pstmt.setString(2, pname);
    	pstmt.setFloat(3, price);
    	
    	int result = pstmt.executeUpdate();
		return result;
	}
	
	
	public int updateProduct(Product product) {
		try {
			Connection con = DBResource.getDbConnection();
			PreparedStatement pstmt = con.prepareStatement("update product set pname =? , price =? where pid = ? ");
			pstmt.setString(1, product.getPname());
			pstmt.setFloat(2, product.getPrice());
			pstmt.setInt(3, product.getPid());
			
			int result =pstmt.executeUpdate();
			System.out.println(result);
			return result ;
			} catch (Exception e) {
				System.err.println("Product update exception"+e);
				return 0;
			}
		
	}
	
	
	public int deleteProduct(int pid) {
		try {
			Connection con = DBResource.getDbConnection();
			PreparedStatement pstmt = con.prepareStatement("delete from product where pid = ?");
			pstmt.setInt(1, pid);
			int result =pstmt.executeUpdate();
			return result ;
			} catch (Exception e) {
			System.err.println("Product delete exception"+e);
				return 0;
			}
	}
}
