package com.com.bean;

public class EncapsulationExample {
	
	
	    private String name; 
	    private int roll;    // we have made name , roll and age private .
	    private int age;    //  so, these can not access directly  
	                       // to accsess it or call it we now have to use setter and getter method.
	   
	    
	    public int getAge()  
	    { 
	    	
	      return age; 
	      
	    } 
	    
	    public String getName()  
	    { 
	      return name; 
	      
	    } 
	    public int getRoll()  
	    { 
	    	
	       return roll; 
	       
	    } 
	    
	    public void setAge( int age) 
	    { 
	      this.age = age; 
	    } 
	    public void setName(String name) 
	    { 
	      this.name = name; 
	    } 
	    public void setRoll( int roll)  
	    { 
	      this.roll = roll; 
	    }
		
	    public static void main (String[] args)  
	    { 
	        EncapsulationExample en = new EncapsulationExample(); 
	        en.setName("Rohit"); 
	        en.setRoll(10);
	        en.setAge(12); 
	         
	        System.out.println("My name: " + en.getName()); 
	        System.out.println("My age: " + en.getAge()); 
	        System.out.println("My roll: " + en.getRoll());      
	    } 


	

}
