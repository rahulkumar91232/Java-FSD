package com;

public class A {
    
	
	
	public static void staticMethod2() {
		
	}


	public void publicMethod1() {
		// TODO Auto-generated method stub
		
	}
	
	
	
	
}
