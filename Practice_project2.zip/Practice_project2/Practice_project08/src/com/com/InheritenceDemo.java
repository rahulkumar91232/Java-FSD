package com.com;


public class InheritenceDemo {
	
	
	public static void main(String[] args) {
		
		
		Mercedes mer = new Mercedes("Black",2, 20);
		  
		mer.run();
	}

}
