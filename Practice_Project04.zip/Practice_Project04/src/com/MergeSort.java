package com;

public class MergeSort {
	
	public static void merge(int num[], int start, int mid, int end) {
		int leftSize = mid-start +1;
		int rightSize = end - mid;
		int leftArray[]=new int[leftSize];
		int rightArray[]= new int[rightSize];
		
		for(int i=0;i<leftSize;i++) {
			leftArray[i]=num[start+i];
		}
		
		for(int j=0;j<rightSize;j++) {
			rightArray[j]=num[mid+1+j];
		}
		int i=0,j=0,k=start;
		
		while(i<leftSize && j < rightSize) {
			if(leftArray[i]>=rightArray[j]) {
				num[k]=leftArray[i];
				i++;
			}else {
				num[k]=rightArray[j];
				j++;
			}
			k++;
		}
		
		while(i<leftSize) {
			num[k]=leftArray[i];
			i++;
			k++;
		}
		
		while(j<rightSize) {
			num[k]=rightArray[j];
			j++;
			k++;
		}
	}
	public static void mergeSort(int num[],int start, int end) {
		if(start < end) {
			int mid = (start+end)/2;
			mergeSort(num, start, mid);
			mergeSort(num, mid+1, end);
			merge(num,start,mid,end);
		}
	}

	
	
	

	public static void main(String[] args) {
		int[] arr = {24,25,29,72,17,102,45,24,23,78};
		mergeSort(arr, 0, arr.length-1);
		
		System.out.println("Array after sorting in descending order");
		for(int a:arr) {
			System.out.print(a+" ");
		}
	}
	

}
