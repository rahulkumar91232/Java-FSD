package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class DbResource {
   static final String DB_URL = "jdbc:mysql://localhost:3306/";
   static final String USER = "root";
   static final String PASS = "8875325200";
   
                Connection con;

  
			   // method to established connection with MYSQL database
			   public void CreateConnection() throws SQLException{
				   
				   try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					        con = DriverManager.getConnection(DB_URL, USER, PASS);
				   } catch (ClassNotFoundException e) {
					
					e.printStackTrace();
				  } 
			   }
			   
			   // method to create Database
			   public int createDatabase(String dbName) throws SQLException {
				   CreateConnection();
				   String sqlQuery = "create database "+dbName; 
				   PreparedStatement pstmt = con.prepareStatement(sqlQuery);
			       int result=pstmt.executeUpdate();
			       System.out.println("result of create database : "+result);
				   return result;
			       
			   }
			   
			   
			   // method to select Database
			   public void selectDatabase(String dbName) throws SQLException {
				   CreateConnection();
				   String sqlQuery = "use "+dbName; 
				   Statement stmt = con.createStatement();
				   stmt.executeUpdate(sqlQuery);
	
			       String sqlQuery1 ="insert into product values(103,'rahul',1111)"; // given a record to insert into product table 
			       stmt.executeUpdate(sqlQuery1); //  in database javatraining to verify whether given database got  selected or not.
				  
			   }
			   // method to delete Database
			   public void deleteDatabase(String dbName) throws SQLException {
				   CreateConnection();
				   String sqlQuery = "drop database "+dbName; 
				   PreparedStatement pstmt = con.prepareStatement(sqlQuery);
			       pstmt.execute();
			      
			       
			   }
   
}
