package com.bean;

public class Database {
   private String dbName;

public String getDbName() {
	return dbName;
}

public void setDbName(String dbName) {
	this.dbName = dbName;
}

public Database(String dbName) {
	super();
	this.dbName = dbName;
}

public Database() {
	super();

}

@Override
public String toString() {
	return "Database [dbName=" + dbName + "]";
}
}
