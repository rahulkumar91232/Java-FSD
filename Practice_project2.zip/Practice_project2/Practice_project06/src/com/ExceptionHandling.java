package com;

public class ExceptionHandling {

	public static void main(String[] args) {
		
		int[] arr= {10,20};
		int num = 100;
		try {
			int res1 = num/arr[0];
			System.out.println("Result is "+res1);
			int res2 = num/arr[2];
			System.out.println("Result is "+res2);
		}
		catch (ArithmeticException e) {
			System.out.println(e);
		}catch(ArrayIndexOutOfBoundsException e) {
			System.out.println(e);
		}catch(Exception e) {
			System.out.println(e);
		}
		
		System.out.println("Program finished");

	}

}
