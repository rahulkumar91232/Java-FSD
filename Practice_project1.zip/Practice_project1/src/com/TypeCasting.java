package com;

public class TypeCasting {
    
	public static void main(String[] args) {
     
		 byte a =10;
		 
		 // implicit types casting 
		 
        short c = a;
        int i = a;
        
        double d = a;
        
        double h = i;
        
        long l = a;
        
        
        // Explicit Type Casting
        
        double p =100;
        
        int m = (int)p;
        
        short s= (short)p;
        
        byte b = (byte)p;
        
        byte z = (byte) m;
        
        byte k = (byte)s;
	}

}
