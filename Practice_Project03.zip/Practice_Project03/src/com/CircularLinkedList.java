package com;



class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class SortedCircularLinkedList {
    Node head;

    // Method to insert a new element into a sorted circular linked list
    void insert(int newData) {
        Node newNode = new Node(newData);

        // If the list is empty, make the new node as the head and point it to itself
        if (head == null) {
            head = newNode;
            newNode.next = head;
        } else {
            Node current = head;

            // If the new node is smaller than the head, insert it before the head
            if (newData < head.data) {
                while (current.next != head) {
                    current = current.next;
                }
                current.next = newNode;
                newNode.next = head;
                head = newNode;
            } else {
                // Find the correct position to insert the new node
                while (current.next != head && current.next.data < newData) {
                    current = current.next;
                }

                // Insert the new node in the sorted order
                newNode.next = current.next;
                current.next = newNode;
            }
        }
    }

    // Method to print the circular linked list
    void printList() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }
}

public class CircularLinkedList {
    public static void main(String[] args) {
        SortedCircularLinkedList circularLinkedList = new SortedCircularLinkedList();

        // Inserting elements into the sorted circular linked list
        circularLinkedList.insert(3);
        circularLinkedList.insert(5);
        circularLinkedList.insert(8);
        circularLinkedList.insert(12);
        circularLinkedList.insert(1);

        // Printing the sorted circular linked list
        circularLinkedList.printList();
    }
}




