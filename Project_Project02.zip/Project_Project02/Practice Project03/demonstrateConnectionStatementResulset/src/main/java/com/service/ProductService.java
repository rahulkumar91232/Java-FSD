package com.service;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.bean.Product;
import com.dao.ProductDao;

public class ProductService {
	
	ProductDao pd= new ProductDao();
	
	public int addProduct(Product product) throws SQLException {
		int result = pd.addProduct(product);
		return result;
		
	}
	
	
	
	
	
	public Product displayProduct(int pid) {
		
		ResultSet rs = pd.retrieveProduct(pid);
		try {
			while(rs.next()) {
				Product  p = new Product();			// converting query into product object. 
				p.setPid(rs.getInt(1));
				p.setPname(rs.getString(2));
				p.setPrice(rs.getFloat(3));
				return p;
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
		
	}

}
