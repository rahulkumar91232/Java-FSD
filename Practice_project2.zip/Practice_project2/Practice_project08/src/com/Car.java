package com;


// This program demonstrate the use of class and object in java .

public class Car {      // class is a blueprint of object . It contains attributes , methods and objects in it.
	
	    String name; 
	    String type; 
	    double price;
	    String color; 
	    
	    
	    public Car(String name, String type, double price, String color) 
	    { 
	        this.name = name; 
	        this.type = type; 
	        this.price = price; 
	        this.color = color; 
	    } 
	    public String getName() 
	    { 
	        return name; 
	    } 
	    public String getType() 
	    { 
	        return type; 
	    } 
	    public double getPrice() 
	    { 
	        return price; 
	    } 
	    public String getColor() 
	    { 
	        return color; 
	    } 
	    @Override
	    public String toString()  // we are OverRideing the String class method toString() here.
	    { 
	        return("car name is "+ this.getName()+ " this is a  " + this.getType()+" car and its price is around " + this.getPrice()+ " and color is "+ this.getColor() + "."); 
	    } 
	    public static void main(String[] args) 
	    { 
	        Car car = new Car("Mercedes-Benz","Diesel Engine",10000000.0, "black"); // class is used to create object and 
	                                                                                //access attributes and method inside class through object created.
	        System.out.println(car.toString()); 
	    } 
	




}
