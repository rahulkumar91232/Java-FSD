package com;

class MathsTable{
	
	
	void showTable(int n) {           //   we create one method named showTable() here .

		for(int i=1 ;i<=10;i++) {
			System.out.println(n*i);

			try {
				Thread.sleep(2000);     // This sleep method make the Thread sleep for 2 seconds.
			}catch(Exception e) {

				System.out.println(e);

			}
		}


	}
}


class Thread1 extends Thread{       // we created one thread here which will run method run(2)
	
	MathsTable mt;
	Thread1(MathsTable mt){
		this.mt=mt;
	}
	public void run() {
		mt.showTable(2);
	}
	
}


class Thread2 extends Thread{     // we created another thread here which will run method run(3)
	
	MathsTable mt;
	Thread2(MathsTable mt){
		this.mt=mt;
	}
	public void run() {
		mt.showTable(3);
	}
	
}





public class SynchronisationDemo {
	

	public static void main(String[] args) {
		
		MathsTable obj = new MathsTable();   // we created object  of Mathstable class
		Thread1 t1 = new Thread1(obj);       //  we created object of Thread1 class  and pass the obj as argrument in it.
		Thread2 t2 = new Thread2(obj);
		t1.start();
		t2.start();
	}
}
