package array;

public class ArrayImplementation {

	public static void main(String[] args) {
		
		int[] marks = new int[11];
		String[] name = new String[11];
		
		marks[0]=90;
		marks[1]=95;
		marks[2]=89;
		marks[3]=46;
		marks[4]=79;
		marks[5]=85;
		marks[6]=92;
		marks[7]=66;
		marks[8]=81;
		marks[9]=83;
		marks[10]=94;
		
		
		System.out.println("marks in the array marks are :");
		for(int m : marks) {
			System.out.print(" "+m);
		}
		System.out.println(" ");
		
		name[0] = "rahul";
		name[1] = "rohit";
		name[2] = "Mukesh";
		name[3] = "Namrata";
		name[4] = "Shilpa";
		name[5] = "Sachin";
		name[6] = "Surya";
		name[7] = "Gill";
		name[8] = "Deepak";
		name[9] = "Hitesh";
		name[10] = "Irfan";
		
		System.out.println("Nmae of student in name array are :");
		for(int i=0; i<name.length;i++) {
			System.out.print(" "+name[i]);
		}
		

	}

}
