package com.com;

class Node {
	int data;
	Node next;
	Node prev;

	public Node(int data) {
		this.data = data;
		this.next = null;
		this.prev = null;
	}
}

class DoublyLinkedList {
	Node head;

	// Method to insert a new node at the end
	void insert(int data) {
		Node newNode = new Node(data);
		if (head == null) {
			head = newNode;
		} else {
			Node temp = head;
			while (temp.next != null) {
				temp = temp.next;
			}
			temp.next = newNode;
			newNode.prev = temp;
		}
	}

	// Method to traverse the list in forward direction
	void traverseForward() {
		System.out.println("Forward traversal:");
		Node temp = head;
		while (temp != null) {
			System.out.print(temp.data + " ");
			temp = temp.next;
		}
		System.out.println();
	}

	// Method to traverse the list in backward direction
	void traverseBackward() {
		System.out.println("Backward traversal:");
		Node temp = head;
		while (temp.next != null) {
			temp = temp.next;
		}
		while (temp != null) {
			System.out.print(temp.data + " ");
			temp = temp.prev;
		}
		System.out.println();
	}
}

public class TraversingDoublyLinkedList {
	public static void main(String[] args) {

		DoublyLinkedList doublyLinkedList = new DoublyLinkedList();

		// Inserting elements into the doubly linked list
		doublyLinkedList.insert(1);
		doublyLinkedList.insert(2);
		doublyLinkedList.insert(3);
		doublyLinkedList.insert(4);


		doublyLinkedList.traverseForward();  // Traversing in forward direction


		doublyLinkedList.traverseBackward();    // Traversing in backward direction
	}
}