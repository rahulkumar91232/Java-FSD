package bean;

public class TryCatchExample {

	public static void main(String[] args) {
		
		
		int a=10;
		
		int b=0;
		
		try {
			
			int c = a/b;
			
			System.out.println("Division result is : "+c);
			
		}catch(Exception e){
			System.out.println("Some exception occured");
			
		}
		System.out.println("Program Completed");

	}

}
