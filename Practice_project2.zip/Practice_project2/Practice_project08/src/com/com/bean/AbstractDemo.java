package com.com.bean;



abstract class Bike {
	abstract void run();
	
}


class Honda extends Bike{

	@Override
	void run() {
		
		System.out.println("Honda is running .");
	}
	
}

public class AbstractDemo {

	public static void main(String[] args) {

   Honda hh = new Honda(); 
    hh.run();
		

	}

}
